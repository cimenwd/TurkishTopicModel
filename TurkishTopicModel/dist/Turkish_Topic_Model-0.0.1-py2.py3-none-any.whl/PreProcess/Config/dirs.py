import os

_path = os.getcwd() + "\\"
_datapath = "TurkishTopicModelData"
_processdir = "processdir"
_esanlamSozluk="TurkishTopicModelData\\kemik\\kelime-esanlamlisi.txt"
_esanlamurl = 'http://nlpapps.cs.deu.edu.tr/esveyakin/sonuc.aspx'
_stoplist="stopwords.txt"
_itutools="http://tools.nlp.itu.edu.tr/SimpleApi"
_itutoken="Bt05DxQSDQmlKHZClgoYb2uDtrHYTgL5"
