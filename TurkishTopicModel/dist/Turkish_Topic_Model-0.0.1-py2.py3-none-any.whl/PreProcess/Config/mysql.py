host="localhost"
user="root"
password=""
db="harezmi"